#!/bin/bash

export LD_LIBRARY_PATH=./
./minerd -a x14 -o stratum+tcp://hcash.uupool.cn:51001 -u HHSSCwHp36F4HdgnhXqv64paqc82sry9sT.workername
